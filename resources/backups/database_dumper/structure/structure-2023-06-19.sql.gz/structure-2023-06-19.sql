-- MySQL dump 10.13  Distrib 8.0.33, for Linux (x86_64)
--
-- Host: SRV011.img.med.uni-tuebingen.de    Database: HerediVar_ahdoebm1
-- ------------------------------------------------------
-- Server version	5.5.5-10.3.37-MariaDB-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `annotation_queue`
--

DROP TABLE IF EXISTS `annotation_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `annotation_queue` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `variant_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `requested` datetime NOT NULL DEFAULT current_timestamp(),
  `status` enum('pending','success','error','retry') NOT NULL DEFAULT 'pending',
  `finished_at` datetime DEFAULT NULL,
  `error_message` text DEFAULT NULL,
  `celery_task_id` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `annotation_queue_variant_idx` (`variant_id`),
  KEY `annotation_queue_user_idx` (`user_id`),
  CONSTRAINT `FK_annotation_queue_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_annotation_queue_variant` FOREIGN KEY (`variant_id`) REFERENCES `variant` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=1305 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `annotation_type`
--

DROP TABLE IF EXISTS `annotation_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `annotation_type` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `display_title` text NOT NULL,
  `description` text NOT NULL,
  `value_type` enum('int','float','text') NOT NULL,
  `version` text DEFAULT NULL COMMENT 'Either the version name of the resource or, if there is no versioning, the date when the resource was accessed.',
  `version_date` date NOT NULL,
  `group_name` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `annotation_type_title_version_date_id` (`title`,`version_date`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assay`
--

DROP TABLE IF EXISTS `assay`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assay` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `variant_id` int(10) unsigned NOT NULL,
  `assay_type` enum('functional','splicing') NOT NULL,
  `report` mediumblob NOT NULL,
  `filename` text NOT NULL,
  `score` float NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_assay_variant_idx` (`variant_id`),
  CONSTRAINT `FK_assay_variant` FOREIGN KEY (`variant_id`) REFERENCES `variant` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `classification_criterium`
--

DROP TABLE IF EXISTS `classification_criterium`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `classification_criterium` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `classification_scheme_id` int(10) unsigned NOT NULL,
  `name` varchar(32) NOT NULL,
  `description` text NOT NULL,
  `is_selectable` tinyint(1) NOT NULL,
  `relevant_info` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_classification_criterium_classification_scheme_id_idx` (`classification_scheme_id`),
  KEY `UNIQUE_scheme_id_name` (`classification_scheme_id`,`name`),
  CONSTRAINT `FK_classification_criterium_classification_scheme_id` FOREIGN KEY (`classification_scheme_id`) REFERENCES `classification_scheme` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=151 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `classification_criterium_strength`
--

DROP TABLE IF EXISTS `classification_criterium_strength`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `classification_criterium_strength` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `classification_criterium_id` int(10) unsigned NOT NULL,
  `name` text NOT NULL,
  `description` text NOT NULL,
  `is_default` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_criterium_strength_classification_criterium_idx` (`classification_criterium_id`),
  CONSTRAINT `FK_criterium_strength_classification_criterium` FOREIGN KEY (`classification_criterium_id`) REFERENCES `classification_criterium` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=367 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `classification_scheme`
--

DROP TABLE IF EXISTS `classification_scheme`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `classification_scheme` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `display_name` text NOT NULL,
  `type` text NOT NULL,
  `reference` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `clinvar_submission`
--

DROP TABLE IF EXISTS `clinvar_submission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clinvar_submission` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `clinvar_variant_annotation_id` int(10) unsigned NOT NULL,
  `interpretation` text NOT NULL,
  `last_evaluated` date DEFAULT NULL,
  `review_status` text NOT NULL,
  `submission_condition` text NOT NULL,
  `submitter` text NOT NULL,
  `comment` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  KEY `FK_clinvar_submissions_clinvar_variant_annotation_idx` (`clinvar_variant_annotation_id`),
  CONSTRAINT `FK_clinvar_submissions_clinvar_variant_annotation` FOREIGN KEY (`clinvar_variant_annotation_id`) REFERENCES `clinvar_variant_annotation` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=8968 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `clinvar_variant_annotation`
--

DROP TABLE IF EXISTS `clinvar_variant_annotation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clinvar_variant_annotation` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `variant_id` int(10) unsigned NOT NULL,
  `variation_id` int(11) unsigned NOT NULL,
  `interpretation` text NOT NULL,
  `review_status` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  KEY `clinvar_variant_annotation_variant_idx` (`variant_id`),
  CONSTRAINT `FK_clinvar_variant_annotation_variant` FOREIGN KEY (`variant_id`) REFERENCES `variant` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=807 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `consensus_classification`
--

DROP TABLE IF EXISTS `consensus_classification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `consensus_classification` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `variant_id` int(10) unsigned NOT NULL,
  `classification` enum('1','2','3','4','5','3+','3-') NOT NULL,
  `comment` text NOT NULL,
  `date` datetime NOT NULL,
  `evidence_document` longblob NOT NULL,
  `is_recent` tinyint(1) NOT NULL DEFAULT 1,
  `classification_scheme_id` int(10) unsigned NOT NULL,
  `scheme_class` enum('1','2','3','4','5') NOT NULL,
  PRIMARY KEY (`id`),
  KEY `consensus_classification_variant_idx` (`variant_id`),
  KEY `FK_variant_consensus_classification_user_idx` (`user_id`),
  KEY `FK_variant_consensus_classification_classification_scheme_idx` (`classification_scheme_id`),
  CONSTRAINT `FK_variant_consensus_classification` FOREIGN KEY (`variant_id`) REFERENCES `variant` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_variant_consensus_classification_classification_scheme` FOREIGN KEY (`classification_scheme_id`) REFERENCES `classification_scheme` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_variant_consensus_classification_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=270 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `consensus_classification_criteria_applied`
--

DROP TABLE IF EXISTS `consensus_classification_criteria_applied`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `consensus_classification_criteria_applied` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `consensus_classification_id` int(10) unsigned NOT NULL,
  `classification_criterium_id` int(10) unsigned NOT NULL,
  `criterium_strength_id` int(10) unsigned NOT NULL,
  `evidence` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_consensus_classification_criteria_applied_consensus_clas_idx` (`consensus_classification_id`),
  KEY `FK_consensus_classification_criteria_applied_classification_idx` (`classification_criterium_id`),
  KEY `FK_consensus_classification_criteria_applied_classification_idx1` (`criterium_strength_id`),
  CONSTRAINT `FK_consensus_classification_criteria_classification_criterium` FOREIGN KEY (`classification_criterium_id`) REFERENCES `classification_criterium` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_consensus_classification_criteria_consensus_classification` FOREIGN KEY (`consensus_classification_id`) REFERENCES `consensus_classification` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_consensus_classification_criteria_criterium_strength` FOREIGN KEY (`criterium_strength_id`) REFERENCES `classification_criterium_strength` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `consensus_classification_selected_literature`
--

DROP TABLE IF EXISTS `consensus_classification_selected_literature`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `consensus_classification_selected_literature` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `classification_id` int(10) unsigned NOT NULL,
  `pmid` int(11) NOT NULL,
  `text_passage` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_consensus_classification_consensus_classification_idx` (`classification_id`),
  CONSTRAINT `FK_consensus_classification_selected_literature_cc` FOREIGN KEY (`classification_id`) REFERENCES `consensus_classification` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gene`
--

DROP TABLE IF EXISTS `gene`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gene` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `hgnc_id` int(11) NOT NULL,
  `symbol` text NOT NULL,
  `name` text NOT NULL,
  `type` text NOT NULL,
  `omim_id` int(11) unsigned DEFAULT NULL,
  `orphanet_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `gene_hgnc_id_idx` (`hgnc_id`)
) ENGINE=InnoDB AUTO_INCREMENT=43130 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gene_alias`
--

DROP TABLE IF EXISTS `gene_alias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gene_alias` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `gene_id` int(10) unsigned NOT NULL,
  `alt_symbol` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_gene_gene_alias_idx` (`gene_id`),
  CONSTRAINT `FK_gene_gene_alias` FOREIGN KEY (`gene_id`) REFERENCES `gene` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=58026 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `heredicare_center_classification`
--

DROP TABLE IF EXISTS `heredicare_center_classification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `heredicare_center_classification` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `classification` enum('1','2','3','4','5') NOT NULL,
  `variant_id` int(10) unsigned NOT NULL,
  `center_name` text NOT NULL,
  `comment` text NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_classification_center_heredicare_variant_idx` (`variant_id`),
  CONSTRAINT `FK_heredicare_center_classification_variant` FOREIGN KEY (`variant_id`) REFERENCES `variant` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `heredivar_clinvar_submissions`
--

DROP TABLE IF EXISTS `heredivar_clinvar_submissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `heredivar_clinvar_submissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `variant_id` int(10) unsigned NOT NULL,
  `submission_id` text NOT NULL,
  `accession_id` text DEFAULT NULL,
  `status` text NOT NULL,
  `message` text NOT NULL,
  `last_updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_heredivar_clinvar_submissions_variant_id` (`variant_id`),
  KEY `FK_heredivar_clinvar_submissions_variant_idx` (`variant_id`),
  CONSTRAINT `FK_heredivar_clinvar_submissions_variant` FOREIGN KEY (`variant_id`) REFERENCES `variant` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `import_queue`
--

DROP TABLE IF EXISTS `import_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `import_queue` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `requested_at` datetime NOT NULL DEFAULT current_timestamp(),
  `status` enum('pending','finished') NOT NULL DEFAULT 'pending',
  `finished_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_import_queue_user_id_idx` (`user_id`),
  CONSTRAINT `FK_import_queue_user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=112 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `list_variants`
--

DROP TABLE IF EXISTS `list_variants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `list_variants` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `list_id` int(10) unsigned NOT NULL,
  `variant_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_list_variants_user_variant_lists_idx` (`list_id`),
  KEY `FK_list_variants_variant_idx` (`variant_id`),
  CONSTRAINT `FK_list_variants_user_variant_lists` FOREIGN KEY (`list_id`) REFERENCES `user_variant_lists` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `FK_list_variants_variant` FOREIGN KEY (`variant_id`) REFERENCES `variant` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=623 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `mutually_exclusive_criteria`
--

DROP TABLE IF EXISTS `mutually_exclusive_criteria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mutually_exclusive_criteria` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `source` int(10) unsigned NOT NULL COMMENT 'This criterium id prevents activation of the target criterium id',
  `target` int(10) unsigned NOT NULL COMMENT 'This criterium id is blocked by the source if it is active',
  PRIMARY KEY (`id`),
  KEY `FK_mutually_exclusive_criteria_classification_criteria_1_idx` (`source`),
  KEY `FK_mutually_exclusive_criteria_classification_criterium_idx` (`target`),
  CONSTRAINT `FK_mutually_exclusive_criteria_classification_criteria_1` FOREIGN KEY (`source`) REFERENCES `classification_criterium` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_mutually_exclusive_criteria_classification_criterium` FOREIGN KEY (`target`) REFERENCES `classification_criterium` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pfam_id_mapping`
--

DROP TABLE IF EXISTS `pfam_id_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pfam_id_mapping` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `accession_id` text NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19633 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pfam_legacy`
--

DROP TABLE IF EXISTS `pfam_legacy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pfam_legacy` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `old_accession_id` text NOT NULL,
  `new_accession_id` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=973 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `task_force_protein_domains`
--

DROP TABLE IF EXISTS `task_force_protein_domains`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `task_force_protein_domains` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `chr` enum('chr1','chr2','chr3','chr4','chr5','chr6','chr7','chr8','chr9','chr10','chr11','chr12','chr13','chr14','chr15','chr16','chr17','chr18','chr19','chr20','chr21','chr22','chrX','chrY','chrMT') NOT NULL,
  `start` int(11) NOT NULL,
  `end` int(11) NOT NULL,
  `description` text NOT NULL,
  `source` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=86 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `transcript`
--

DROP TABLE IF EXISTS `transcript`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transcript` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `gene_id` int(10) unsigned NOT NULL,
  `name` varchar(50) NOT NULL,
  `biotype` text NOT NULL,
  `length` int(11) NOT NULL,
  `is_gencode_basic` tinyint(1) NOT NULL,
  `is_mane_select` tinyint(1) NOT NULL,
  `is_mane_plus_clinical` tinyint(1) NOT NULL,
  `is_ensembl_canonical` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_transcript_gene` (`gene_id`),
  KEY `INDEX_transcript_name` (`name`),
  CONSTRAINT `FK_transcript_gene` FOREIGN KEY (`gene_id`) REFERENCES `gene` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=363829 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(200) NOT NULL,
  `first_name` text NOT NULL,
  `last_name` text NOT NULL,
  `affiliation` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username_UNIQUE` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=89 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_classification`
--

DROP TABLE IF EXISTS `user_classification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_classification` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `classification` enum('1','2','3','4','5','3-','3+') NOT NULL,
  `variant_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `comment` text NOT NULL,
  `date` datetime NOT NULL,
  `classification_scheme_id` int(10) unsigned NOT NULL,
  `scheme_class` enum('-','1','2','3','4','5') NOT NULL,
  PRIMARY KEY (`id`),
  KEY `classification_variant_idx` (`variant_id`),
  KEY `classification_user_idx` (`user_id`),
  KEY `FK_user_classification_classification_scheme_idx` (`classification_scheme_id`),
  CONSTRAINT `FK_user_classification` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_user_classification_classification_scheme` FOREIGN KEY (`classification_scheme_id`) REFERENCES `classification_scheme` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_variant_classification` FOREIGN KEY (`variant_id`) REFERENCES `variant` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_classification_criteria_applied`
--

DROP TABLE IF EXISTS `user_classification_criteria_applied`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_classification_criteria_applied` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_classification_id` int(10) unsigned NOT NULL,
  `classification_criterium_id` int(10) unsigned NOT NULL,
  `criterium_strength_id` int(10) unsigned NOT NULL,
  `evidence` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_user_classification_criteria_applied_user_classification_idx` (`user_classification_id`),
  KEY `FK_user_classification_criteria_applied_classification_crit_idx` (`classification_criterium_id`),
  KEY `FK_user_classification_criteria_applied_criterium_strength_idx` (`criterium_strength_id`),
  CONSTRAINT `FK_user_classification_criteria_applied_classification_criterium` FOREIGN KEY (`classification_criterium_id`) REFERENCES `classification_criterium` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_user_classification_criteria_applied_criterium_strength` FOREIGN KEY (`criterium_strength_id`) REFERENCES `classification_criterium_strength` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_user_classification_criteria_applied_user_classification` FOREIGN KEY (`user_classification_id`) REFERENCES `user_classification` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=92 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_classification_selected_literature`
--

DROP TABLE IF EXISTS `user_classification_selected_literature`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_classification_selected_literature` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `classification_id` int(10) unsigned NOT NULL,
  `pmid` int(11) NOT NULL,
  `text_passage` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_key_classification_id_pmid` (`classification_id`,`pmid`),
  KEY `FK_user_classification_selected_literature_user_classificat_idx` (`classification_id`,`pmid`),
  CONSTRAINT `FK_user_classification_selected_literature_user_classification` FOREIGN KEY (`classification_id`) REFERENCES `user_classification` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=213 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_variant_lists`
--

DROP TABLE IF EXISTS `user_variant_lists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_variant_lists` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `name` text NOT NULL,
  `public_read` tinyint(1) NOT NULL DEFAULT 0,
  `public_edit` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `FK_user_variant_lists_user_idx` (`user_id`),
  CONSTRAINT `FK_user_variant_lists_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `variant`
--

DROP TABLE IF EXISTS `variant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `variant` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `chr` enum('chr1','chr2','chr3','chr4','chr5','chr6','chr7','chr8','chr9','chr10','chr11','chr12','chr13','chr14','chr15','chr16','chr17','chr18','chr19','chr20','chr21','chr22','chrX','chrY','chrMT') NOT NULL,
  `pos` int(10) unsigned NOT NULL,
  `ref` text NOT NULL,
  `alt` text NOT NULL,
  `error` tinyint(1) NOT NULL DEFAULT 0,
  `error_description` text DEFAULT NULL,
  `orig_chr` enum('chr1','chr2','chr3','chr4','chr5','chr6','chr7','chr8','chr9','chr10','chr11','chr12','chr13','chr14','chr15','chr16','chr17','chr18','chr19','chr20','chr21','chr22','chrX','chrY','chrMT') NOT NULL,
  `orig_pos` int(10) unsigned NOT NULL DEFAULT 0,
  `orig_ref` text NOT NULL,
  `orig_alt` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=176 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `variant_annotation`
--

DROP TABLE IF EXISTS `variant_annotation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `variant_annotation` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `variant_id` int(11) unsigned NOT NULL,
  `annotation_type_id` int(11) unsigned NOT NULL,
  `value` text NOT NULL,
  `supplementary_document` blob DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `variant_id_annotation_type_id_UNIQUE` (`variant_id`,`annotation_type_id`),
  KEY `variant_annotation_variant_idx` (`variant_id`),
  KEY `variant_annotation_variant_type_idx` (`annotation_type_id`),
  CONSTRAINT `variant` FOREIGN KEY (`variant_id`) REFERENCES `variant` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `variant_type` FOREIGN KEY (`annotation_type_id`) REFERENCES `annotation_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=19920 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `variant_consequence`
--

DROP TABLE IF EXISTS `variant_consequence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `variant_consequence` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `variant_id` int(11) unsigned NOT NULL,
  `transcript_name` text NOT NULL,
  `hgvs_c` text DEFAULT NULL,
  `hgvs_p` text DEFAULT NULL,
  `consequence` text NOT NULL,
  `impact` enum('high','moderate','low','modifier') NOT NULL,
  `exon_nr` int(11) unsigned DEFAULT NULL,
  `intron_nr` int(11) unsigned DEFAULT NULL,
  `hgnc_id` int(11) unsigned DEFAULT NULL,
  `source` enum('ensembl','refseq') NOT NULL,
  `pfam_accession` varchar(45) DEFAULT NULL,
  `pfam_description` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `variant_consequence_variant_idx` (`variant_id`),
  KEY `variant_consequence_hgnc_id_idx` (`hgnc_id`),
  CONSTRAINT `FK_variant_variant_consequence` FOREIGN KEY (`variant_id`) REFERENCES `variant` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=1789 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `variant_ids`
--

DROP TABLE IF EXISTS `variant_ids`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `variant_ids` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `variant_id` int(11) unsigned NOT NULL,
  `external_id` varchar(200) NOT NULL,
  `id_source` varchar(200) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `variant_id_external_id_id_source_key` (`variant_id`,`external_id`,`id_source`),
  KEY `FK_variant_ids_variant_idx` (`variant_id`),
  CONSTRAINT `FK_variant_ids_variant` FOREIGN KEY (`variant_id`) REFERENCES `variant` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `variant_literature`
--

DROP TABLE IF EXISTS `variant_literature`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `variant_literature` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `variant_id` int(10) unsigned NOT NULL,
  `pmid` int(11) NOT NULL,
  `title` text NOT NULL,
  `authors` text NOT NULL,
  `journal_publisher` text NOT NULL,
  `year` int(11) DEFAULT NULL COMMENT 'year corresponds to the ArticleDate for pubmed articles, PubDate for books or the journal issue -> pubdate if the former two were missing from the entry. If neither of the aforementioned entries is found this field is filled with the empty string',
  `source` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_variant_literature_variant_idx` (`variant_id`),
  CONSTRAINT `FK_variant_literature_variant` FOREIGN KEY (`variant_id`) REFERENCES `variant` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=6754 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-06-19 11:51:10
