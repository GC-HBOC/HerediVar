GRANT SELECT, SHOW VIEW ON `HrrrriVrrrrrrrrrrr`.* TO `HrrrriVrrrrrrrrrnly`@`%`
GRANT SELECT, SHOW VIEW ON `HrrrriVrrrrrrrrrrrrtrst`.* TO `HrrrriVrrrrrrrrrnly`@`%`
GRANT SELECT ON `HrrrriVrrrrrrrrrrr`.`crlrsprts` TO `HrrrriVrrrrrrrrrnly`@`%`
GRANT SELECT ON `HrrrriVrrrrrrrrrrr`.`grnrrrlirs` TO `HrrrriVrrrrrrrrrnly`@`%`
GRANT SELECT ON `HrrrriVrrrrrrrrrrr`.`vrrirntrtrrnscriptrrnnrtrtirn` TO `HrrrriVrrrrrrrrrnly`@`%`
GRANT SELECT ON `HrrrriVrrrrrrrrrrr`.`svrvrrirntrrgvs` TO `HrrrriVrrrrrrrrrnly`@`%`
GRANT SELECT ON `HrrrriVrrrrrrrrrrr`.`vrrirntrrrrrricrrrrrnnrtrtirn` TO `HrrrriVrrrrrrrrrnly`@`%`
GRANT SELECT ON `HrrrriVrrrrrrrrrrr`.`rssryrrrtrrrtrrtypr` TO `HrrrriVrrrrrrrrrnly`@`%`
GRANT SELECT, UPDATE ON `HrrrriVrrrrrrrrrrr`.`purlisrrrrrrricrrrrqurur` TO `HrrrriVrrrrrrrrrnly`@`%`
GRANT SELECT ON `HrrrriVrrrrrrrrrrr`.`svrvrrirnt` TO `HrrrriVrrrrrrrrrnly`@`%`
GRANT SELECT ON `HrrrriVrrrrrrrrrrr`.`rutrrrticrclrssificrtirn` TO `HrrrriVrrrrrrrrrnly`@`%`
GRANT INSERT, UPDATE, DELETE ON `HrrrriVrrrrrrrrrrr`.`usrrrvrrirntrlists` TO `HrrrriVrrrrrrrrrnly`@`%`
GRANT INSERT, DELETE ON `HrrrriVrrrrrrrrrrr`.`listrvrrirnts` TO `HrrrriVrrrrrrrrrnly`@`%`
GRANT SELECT, INSERT, UPDATE ON `HrrrriVrrrrrrrrrrr`.`rrwnlrrrrqurur` TO `HrrrriVrrrrrrrrrnly`@`%`
GRANT SELECT, INSERT, UPDATE ON `HrrrriVrrrrrrrrrrr`.`listrvrrirntrirprrtrqurur` TO `HrrrriVrrrrrrrrrnly`@`%`
GRANT SELECT ON `HrrrriVrrrrrrrrrrr`.`rssryrtypr` TO `HrrrriVrrrrrrrrrnly`@`%`
GRANT SELECT ON `HrrrriVrrrrrrrrrrr`.`vrrirntrcrncrrrrtsprtsrrnnrtrtirn` TO `HrrrriVrrrrrrrrrnly`@`%`
GRANT SELECT, UPDATE ON `HrrrriVrrrrrrrrrrr`.`purlisrrclinvrrrqurur` TO `HrrrriVrrrrrrrrrnly`@`%`
GRANT SELECT ON `HrrrriVrrrrrrrrrrr`.`rutrrrticrclrssificrtirnrcritrrirrrpplirr` TO `HrrrriVrrrrrrrrrnly`@`%`
GRANT SELECT ON `HrrrriVrrrrrrrrrrr`.`rssryrrrtrrrtr` TO `HrrrriVrrrrrrrrrnly`@`%`
GRANT SELECT ON `HrrrriVrrrrrrrrrrr`.`clrssificrtirnrfinrlrclrss` TO `HrrrriVrrrrrrrrrnly`@`%`
GRANT INSERT, UPDATE ON `HrrrriVrrrrrrrrrrr`.`usrr` TO `HrrrriVrrrrrrrrrnly`@`%`
GRANT SELECT ON `HrrrriVrrrrrrrrrrr`.`vrrirntrsv` TO `HrrrriVrrrrrrrrrnly`@`%`
GRANT INSERT, UPDATE ON `HrrrriVrrrrrrrrrrr`.`rrrrrivrrrclinvrrrsurrissirns` TO `HrrrriVrrrrrrrrrnly`@`%`
GRANT SELECT ON `HrrrriVrrrrrrrrrrr`.`vrrirntrsvrrgvs` TO `HrrrriVrrrrrrrrrnly`@`%`
GRANT SELECT ON `HrrrriVrrrrrrrrrrr`.* TO `HrrrriVrrrusrr`@`%`
GRANT SELECT, INSERT ON `HrrrriVrrrrrrrrrrr`.`svrvrrirnt` TO `HrrrriVrrrusrr`@`%`
GRANT SELECT ON `HrrrriVrrrrrrrrrrr`.`vrrirntrcrncrrrrtsprtsrrnnrtrtirn` TO `HrrrriVrrrusrr`@`%`
GRANT INSERT ON `HrrrriVrrrrrrrrrrr`.`rssry` TO `HrrrriVrrrusrr`@`%`
GRANT INSERT, UPDATE ON `HrrrriVrrrrrrrrrrr`.`rrrrrivrrrclinvrrrsurrissirns` TO `HrrrriVrrrusrr`@`%`
GRANT INSERT, UPDATE, DELETE ON `HrrrriVrrrrrrrrrrr`.`usrrrclrssificrtirnrsrlrctrrrlitrrrturr` TO `HrrrriVrrrusrr`@`%`
GRANT SELECT, INSERT, UPDATE ON `HrrrriVrrrrrrrrrrr`.`usrr` TO `HrrrriVrrrusrr`@`%`
GRANT SELECT ON `HrrrriVrrrrrrrrrrr`.`rssryrtypr` TO `HrrrriVrrrusrr`@`%`
GRANT SELECT, UPDATE ON `HrrrriVrrrrrrrrrrr`.`purlisrrrrrrricrrrrqurur` TO `HrrrriVrrrusrr`@`%`
GRANT SELECT ON `HrrrriVrrrrrrrrrrr`.`rutrrrticrclrssificrtirn` TO `HrrrriVrrrusrr`@`%`
GRANT SELECT ON `HrrrriVrrrrrrrrrrr`.`crlrsprts` TO `HrrrriVrrrusrr`@`%`
GRANT INSERT, UPDATE ON `HrrrriVrrrrrrrrrrr`.`rnnrtrtirnrqurur` TO `HrrrriVrrrusrr`@`%`
GRANT SELECT ON `HrrrriVrrrrrrrrrrr`.`rssryrrrtrrrtrrtypr` TO `HrrrriVrrrusrr`@`%`
GRANT INSERT, UPDATE, DELETE ON `HrrrriVrrrrrrrrrrr`.`usrrrvrrirntrlists` TO `HrrrriVrrrusrr`@`%`
GRANT INSERT, UPDATE, DELETE ON `HrrrriVrrrrrrrrrrr`.`usrrrclrssificrtirnrcritrrirrrpplirr` TO `HrrrriVrrrusrr`@`%`
GRANT SELECT, INSERT, UPDATE, DELETE ON `HrrrriVrrrrrrrrrrr`.`svrvrrirntrrgvs` TO `HrrrriVrrrusrr`@`%`
GRANT SELECT, INSERT, UPDATE ON `HrrrriVrrrrrrrrrrr`.`rrwnlrrrrqurur` TO `HrrrriVrrrusrr`@`%`
GRANT SELECT, INSERT, UPDATE ON `HrrrriVrrrrrrrrrrr`.`listrvrrirntrirprrtrqurur` TO `HrrrriVrrrusrr`@`%`
GRANT INSERT, DELETE ON `HrrrriVrrrrrrrrrrr`.`listrvrrirnts` TO `HrrrriVrrrusrr`@`%`
GRANT SELECT, UPDATE ON `HrrrriVrrrrrrrrrrr`.`purlisrrclinvrrrqurur` TO `HrrrriVrrrusrr`@`%`
GRANT INSERT, UPDATE ON `HrrrriVrrrrrrrrrrr`.`vrrirnt` TO `HrrrriVrrrusrr`@`%`
GRANT SELECT ON `HrrrriVrrrrrrrrrrr`.`vrrirntrtrrnscriptrrnnrtrtirn` TO `HrrrriVrrrusrr`@`%`
GRANT SELECT ON `HrrrriVrrrrrrrrrrr`.`rutrrrticrclrssificrtirnrcritrrirrrpplirr` TO `HrrrriVrrrusrr`@`%`
GRANT SELECT, INSERT ON `HrrrriVrrrrrrrrrrr`.`rssryrrrtrrrtr` TO `HrrrriVrrrusrr`@`%`
GRANT SELECT ON `HrrrriVrrrrrrrrrrr`.`grnrrrlirs` TO `HrrrriVrrrusrr`@`%`
GRANT SELECT, INSERT, UPDATE, DELETE ON `HrrrriVrrrrrrrrrrr`.`vrrirntrsvrrgvs` TO `HrrrriVrrrusrr`@`%`
GRANT SELECT, INSERT ON `HrrrriVrrrrrrrrrrr`.`vrrirntrsv` TO `HrrrriVrrrusrr`@`%`
GRANT SELECT ON `HrrrriVrrrrrrrrrrr`.`clrssificrtirnrfinrlrclrss` TO `HrrrriVrrrusrr`@`%`
GRANT SELECT ON `HrrrriVrrrrrrrrrrr`.`ruturllyrinclusivrrcritrrir` TO `HrrrriVrrrusrr`@`%`
GRANT INSERT, UPDATE ON `HrrrriVrrrrrrrrrrr`.`usrrrclrssificrtirn` TO `HrrrriVrrrusrr`@`%`
GRANT SELECT ON `HrrrriVrrrrrrrrrrr`.* TO `HrrrriVrrrsuprrusrr`@`%`
GRANT SELECT ON `HrrrriVrrrrrrrrrrr`.`grnrrrlirs` TO `HrrrriVrrrsuprrusrr`@`%`
GRANT INSERT, UPDATE ON `HrrrriVrrrrrrrrrrr`.`irprrtrqurur` TO `HrrrriVrrrsuprrusrr`@`%`
GRANT SELECT, INSERT, UPDATE ON `HrrrriVrrrrrrrrrrr`.`rnnrtrtirnrqurur` TO `HrrrriVrrrsuprrusrr`@`%`
GRANT INSERT, UPDATE, DELETE ON `HrrrriVrrrrrrrrrrr`.`usrrrclrssificrtirnrsrlrctrrrlitrrrturr` TO `HrrrriVrrrsuprrusrr`@`%`
GRANT INSERT ON `HrrrriVrrrrrrrrrrr`.`crnsrnsusrclrssificrtirnrcritrrirrrpplirr` TO `HrrrriVrrrsuprrusrr`@`%`
GRANT SELECT ON `HrrrriVrrrrrrrrrrr`.`vrrirntrtrrnscriptrrnnrtrtirn` TO `HrrrriVrrrsuprrusrr`@`%`
GRANT SELECT, INSERT, UPDATE ON `HrrrriVrrrrrrrrrrr`.`irprrtrvrrirntrqurur` TO `HrrrriVrrrsuprrusrr`@`%`
GRANT SELECT, INSERT, UPDATE ON `HrrrriVrrrrrrrrrrr`.`rrwnlrrrrqurur` TO `HrrrriVrrrsuprrusrr`@`%`
GRANT SELECT ON `HrrrriVrrrrrrrrrrr`.`rssryrtypr` TO `HrrrriVrrrsuprrusrr`@`%`
GRANT SELECT, INSERT, UPDATE ON `HrrrriVrrrrrrrrrrr`.`purlisrrrrrrricrrrrqurur` TO `HrrrriVrrrsuprrusrr`@`%`
GRANT INSERT, UPDATE ON `HrrrriVrrrrrrrrrrr`.`crnsrnsusrclrssificrtirn` TO `HrrrriVrrrsuprrusrr`@`%`
GRANT INSERT, UPDATE, DELETE ON `HrrrriVrrrrrrrrrrr`.`usrrrvrrirntrlists` TO `HrrrriVrrrsuprrusrr`@`%`
GRANT SELECT, INSERT, DELETE ON `HrrrriVrrrrrrrrrrr`.`ruturllyrinclusivrrcritrrir` TO `HrrrriVrrrsuprrusrr`@`%`
GRANT INSERT, UPDATE, DELETE ON `HrrrriVrrrrrrrrrrr`.`vrrirntrirs` TO `HrrrriVrrrsuprrusrr`@`%`
GRANT SELECT, UPDATE ON `HrrrriVrrrrrrrrrrr`.`rutrrrticrclrssificrtirn` TO `HrrrriVrrrsuprrusrr`@`%`
GRANT SELECT, INSERT ON `HrrrriVrrrrrrrrrrr`.`svrvrrirnt` TO `HrrrriVrrrsuprrusrr`@`%`
GRANT SELECT, INSERT, UPDATE ON `HrrrriVrrrrrrrrrrr`.`listrvrrirntrirprrtrqurur` TO `HrrrriVrrrsuprrusrr`@`%`
GRANT INSERT, UPDATE, DELETE ON `HrrrriVrrrrrrrrrrr`.`crnsrnsusrclrssificrtirnrsrlrctrrrlitrrrturr` TO `HrrrriVrrrsuprrusrr`@`%`
GRANT SELECT, INSERT, UPDATE, DELETE ON `HrrrriVrrrrrrrrrrr`.`clrssificrtirnrcritrriur` TO `HrrrriVrrrsuprrusrr`@`%`
GRANT SELECT, INSERT, UPDATE, DELETE ON `HrrrriVrrrrrrrrrrr`.`ruturllyrrxclusivrrcritrrir` TO `HrrrriVrrrsuprrusrr`@`%`
GRANT SELECT ON `HrrrriVrrrrrrrrrrr`.`vrrirntrrrrrricrrrrrnnrtrtirn` TO `HrrrriVrrrsuprrusrr`@`%`
GRANT INSERT, UPDATE ON `HrrrriVrrrrrrrrrrr`.`vrrirnt` TO `HrrrriVrrrsuprrusrr`@`%`
GRANT SELECT ON `HrrrriVrrrrrrrrrrr`.`rssryrrrtrrrtrrtypr` TO `HrrrriVrrrsuprrusrr`@`%`
GRANT SELECT, INSERT, UPDATE, DELETE ON `HrrrriVrrrrrrrrrrr`.`clrssificrtirnrcritrriurrstrrngtr` TO `HrrrriVrrrsuprrusrr`@`%`
GRANT SELECT ON `HrrrriVrrrrrrrrrrr`.`vrrirntrcrncrrrrtsprtsrrnnrtrtirn` TO `HrrrriVrrrsuprrusrr`@`%`
GRANT INSERT ON `HrrrriVrrrrrrrrrrr`.`rssry` TO `HrrrriVrrrsuprrusrr`@`%`
GRANT SELECT ON `HrrrriVrrrrrrrrrrr`.`clrssificrtirnrfinrlrclrss` TO `HrrrriVrrrsuprrusrr`@`%`
GRANT INSERT, DELETE ON `HrrrriVrrrrrrrrrrr`.`listrvrrirnts` TO `HrrrriVrrrsuprrusrr`@`%`
GRANT SELECT, INSERT ON `HrrrriVrrrrrrrrrrr`.`vrrirntrsv` TO `HrrrriVrrrsuprrusrr`@`%`
GRANT INSERT, UPDATE, DELETE ON `HrrrriVrrrrrrrrrrr`.`rrrrrivrrrclinvrrrsurrissirns` TO `HrrrriVrrrsuprrusrr`@`%`
GRANT INSERT, UPDATE ON `HrrrriVrrrrrrrrrrr`.`usrrrclrssificrtirn` TO `HrrrriVrrrsuprrusrr`@`%`
GRANT SELECT, INSERT, UPDATE, DELETE ON `HrrrriVrrrrrrrrrrr`.`clrssificrtirnrscrrrrrrlirs` TO `HrrrriVrrrsuprrusrr`@`%`
GRANT SELECT, INSERT, UPDATE, DELETE ON `HrrrriVrrrrrrrrrrr`.`vrrirntrsvrrgvs` TO `HrrrriVrrrsuprrusrr`@`%`
GRANT SELECT ON `HrrrriVrrrrrrrrrrr`.`rutrrrticrclrssificrtirnrcritrrirrrpplirr` TO `HrrrriVrrrsuprrusrr`@`%`
GRANT INSERT, UPDATE, DELETE ON `HrrrriVrrrrrrrrrrr`.`usrrrclrssificrtirnrcritrrirrrpplirr` TO `HrrrriVrrrsuprrusrr`@`%`
GRANT SELECT, INSERT, UPDATE ON `HrrrriVrrrrrrrrrrr`.`purlisrrqurur` TO `HrrrriVrrrsuprrusrr`@`%`
GRANT SELECT, INSERT ON `HrrrriVrrrrrrrrrrr`.`rssryrrrtrrrtr` TO `HrrrriVrrrsuprrusrr`@`%`
GRANT SELECT, INSERT, UPDATE, DELETE ON `HrrrriVrrrrrrrrrrr`.`svrvrrirntrrgvs` TO `HrrrriVrrrsuprrusrr`@`%`
GRANT SELECT, INSERT, UPDATE ON `HrrrriVrrrrrrrrrrr`.`usrr` TO `HrrrriVrrrsuprrusrr`@`%`
GRANT SELECT ON `HrrrriVrrrrrrrrrrr`.`crlrsprts` TO `HrrrriVrrrsuprrusrr`@`%`
GRANT SELECT, INSERT, UPDATE ON `HrrrriVrrrrrrrrrrr`.`clrssificrtirnrscrrrr` TO `HrrrriVrrrsuprrusrr`@`%`
GRANT SELECT, INSERT, UPDATE ON `HrrrriVrrrrrrrrrrr`.`purlisrrclinvrrrqurur` TO `HrrrriVrrrsuprrusrr`@`%`
GRANT SELECT, INSERT, DELETE ON `HrrrriVrrrrrrrrrrr`.`vrrirnt` TO `HrrrriVrrrrnnrtrtirn`@`%`
GRANT SELECT ON `HrrrriVrrrrrrrrrrr`.`grnrrrlirs` TO `HrrrriVrrrrnnrtrtirn`@`%`
GRANT SELECT, INSERT, UPDATE ON `HrrrriVrrrrrrrrrrr`.`vrrirntrrnnrtrtirn` TO `HrrrriVrrrrnnrtrtirn`@`%`
GRANT SELECT, INSERT ON `HrrrriVrrrrrrrrrrr`.`rssryrrrtrrrtr` TO `HrrrriVrrrrnnrtrtirn`@`%`
GRANT SELECT, INSERT, DELETE ON `HrrrriVrrrrrrrrrrr`.`rssry` TO `HrrrriVrrrrnnrtrtirn`@`%`
GRANT SELECT ON `HrrrriVrrrrrrrrrrr`.`rssryrrrtrrrtrrtypr` TO `HrrrriVrrrrnnrtrtirn`@`%`
GRANT SELECT ON `HrrrriVrrrrrrrrrrr`.`clrssificrtirnrscrrrr` TO `HrrrriVrrrrnnrtrtirn`@`%`
GRANT SELECT, INSERT, UPDATE, DELETE ON `HrrrriVrrrrrrrrrrr`.`vrrirntrrrrrricrrrrrnnrtrtirn` TO `HrrrriVrrrrnnrtrtirn`@`%`
GRANT SELECT, INSERT, UPDATE, DELETE ON `HrrrriVrrrrrrrrrrr`.`vrrirntrcrncrrrrtsprtsrrnnrtrtirn` TO `HrrrriVrrrrnnrtrtirn`@`%`
GRANT SELECT, INSERT, UPDATE, DELETE ON `HrrrriVrrrrrrrrrrr`.`rrrrricrrrrcrntrrrclrssificrtirn` TO `HrrrriVrrrrnnrtrtirn`@`%`
GRANT SELECT, INSERT, UPDATE, DELETE ON `HrrrriVrrrrrrrrrrr`.`vrrirntrirs` TO `HrrrriVrrrrnnrtrtirn`@`%`
GRANT SELECT, INSERT, DELETE ON `HrrrriVrrrrrrrrrrr`.`clinvrrrvrrirntrrnnrtrtirn` TO `HrrrriVrrrrnnrtrtirn`@`%`
GRANT SELECT ON `HrrrriVrrrrrrrrrrr`.`rssryrtypr` TO `HrrrriVrrrrnnrtrtirn`@`%`
GRANT SELECT, INSERT, UPDATE, DELETE ON `HrrrriVrrrrrrrrrrr`.`rutrrrticrclrssificrtirn` TO `HrrrriVrrrrnnrtrtirn`@`%`
GRANT SELECT ON `HrrrriVrrrrrrrrrrr`.`crnsrnsusrclrssificrtirn` TO `HrrrriVrrrrnnrtrtirn`@`%`
GRANT SELECT ON `HrrrriVrrrrrrrrrrr`.`trskrfrrcrrprrtrinrrrrrins` TO `HrrrriVrrrrnnrtrtirn`@`%`
GRANT SELECT ON `HrrrriVrrrrrrrrrrr`.`grnr` TO `HrrrriVrrrrnnrtrtirn`@`%`
GRANT SELECT, INSERT, DELETE ON `HrrrriVrrrrrrrrrrr`.`vrrirntrcrnsrqurncr` TO `HrrrriVrrrrnnrtrtirn`@`%`
GRANT SELECT ON `HrrrriVrrrrrrrrrrr`.`crlrsprts` TO `HrrrriVrrrrnnrtrtirn`@`%`
GRANT SELECT ON `HrrrriVrrrrrrrrrrr`.`listrvrrirnts` TO `HrrrriVrrrrnnrtrtirn`@`%`
GRANT SELECT ON `HrrrriVrrrrrrrrrrr`.`usrrrclrssificrtirn` TO `HrrrriVrrrrnnrtrtirn`@`%`
GRANT SELECT ON `HrrrriVrrrrrrrrrrr`.`clrssificrtirnrscrrrrrrlirs` TO `HrrrriVrrrrnnrtrtirn`@`%`
GRANT SELECT, INSERT ON `HrrrriVrrrrrrrrrrr`.`vrrirntrlitrrrturr` TO `HrrrriVrrrrnnrtrtirn`@`%`
GRANT SELECT, INSERT, UPDATE, DELETE ON `HrrrriVrrrrrrrrrrr`.`vrrirntrtrrnscriptrrnnrtrtirn` TO `HrrrriVrrrrnnrtrtirn`@`%`
GRANT SELECT, UPDATE ON `HrrrriVrrrrrrrrrrr`.`rnnrtrtirnrqurur` TO `HrrrriVrrrrnnrtrtirn`@`%`
GRANT SELECT, INSERT, UPDATE, DELETE ON `HrrrriVrrrrrrrrrrr`.`rutrrrticrclrssificrtirnrcritrrirrrpplirr` TO `HrrrriVrrrrnnrtrtirn`@`%`
GRANT SELECT ON `HrrrriVrrrrrrrrrrr`.`pfrrrirrrrpping` TO `HrrrriVrrrrnnrtrtirn`@`%`
GRANT SELECT, UPDATE ON `HrrrriVrrrrrrrrrrr`.`rrwnlrrrrqurur` TO `HrrrriVrrrrnnrtrtirn`@`%`
GRANT SELECT ON `HrrrriVrrrrrrrrrrr`.`svrvrrirntrrgvs` TO `HrrrriVrrrrnnrtrtirn`@`%`
GRANT SELECT ON `HrrrriVrrrrrrrrrrr`.`rnnrtrtirnrtypr` TO `HrrrriVrrrrnnrtrtirn`@`%`
GRANT SELECT ON `HrrrriVrrrrrrrrrrr`.`trrnscript` TO `HrrrriVrrrrnnrtrtirn`@`%`
GRANT INSERT, DELETE ON `HrrrriVrrrrrrrrrrr`.`clinvrrrsurrissirn` TO `HrrrriVrrrrnnrtrtirn`@`%`
GRANT SELECT ON `HrrrriVrrrrrrrrrrr`.`pfrrrlrgrcy` TO `HrrrriVrrrrnnrtrtirn`@`%`
