GRANT SELECT, SHOW VIEW ON `HerediVar_ahdoebm1`.* TO `HerediVar_read_only`@`%`
GRANT SELECT, SHOW VIEW ON `HerediVar_ahdoebm1_test`.* TO `HerediVar_read_only`@`%`
GRANT SELECT ON `HerediVar_ahdoebm1`.`gene_alias` TO `HerediVar_read_only`@`%`
GRANT SELECT ON `HerediVar_ahdoebm1`.`automatic_classification_criteria_applied` TO `HerediVar_read_only`@`%`
GRANT SELECT ON `HerediVar_ahdoebm1`.`assay_metadata_type` TO `HerediVar_read_only`@`%`
GRANT SELECT ON `HerediVar_ahdoebm1`.`variant_cancerhotspots_annotation` TO `HerediVar_read_only`@`%`
GRANT SELECT ON `HerediVar_ahdoebm1`.`coldspots` TO `HerediVar_read_only`@`%`
GRANT SELECT ON `HerediVar_ahdoebm1`.`sv_variant` TO `HerediVar_read_only`@`%`
GRANT SELECT ON `HerediVar_ahdoebm1`.`variant_sv_hgvs` TO `HerediVar_read_only`@`%`
GRANT SELECT ON `HerediVar_ahdoebm1`.`variant_heredicare_annotation` TO `HerediVar_read_only`@`%`
GRANT INSERT, DELETE ON `HerediVar_ahdoebm1`.`list_variants` TO `HerediVar_read_only`@`%`
GRANT INSERT, UPDATE, DELETE ON `HerediVar_ahdoebm1`.`user_variant_lists` TO `HerediVar_read_only`@`%`
GRANT SELECT ON `HerediVar_ahdoebm1`.`variant_transcript_annotation` TO `HerediVar_read_only`@`%`
GRANT INSERT, UPDATE ON `HerediVar_ahdoebm1`.`heredivar_clinvar_submissions` TO `HerediVar_read_only`@`%`
GRANT SELECT, INSERT, UPDATE ON `HerediVar_ahdoebm1`.`list_variant_import_queue` TO `HerediVar_read_only`@`%`
GRANT SELECT ON `HerediVar_ahdoebm1`.`assay_type` TO `HerediVar_read_only`@`%`
GRANT SELECT ON `HerediVar_ahdoebm1`.`assay_metadata` TO `HerediVar_read_only`@`%`
GRANT SELECT ON `HerediVar_ahdoebm1`.`automatic_classification` TO `HerediVar_read_only`@`%`
GRANT SELECT ON `HerediVar_ahdoebm1`.`sv_variant_hgvs` TO `HerediVar_read_only`@`%`
GRANT INSERT, UPDATE ON `HerediVar_ahdoebm1`.`user` TO `HerediVar_read_only`@`%`
GRANT SELECT ON `HerediVar_ahdoebm1`.`variant_sv` TO `HerediVar_read_only`@`%`
GRANT SELECT ON `HerediVar_ahdoebm1`.* TO `HerediVar_user`@`%`
GRANT SELECT, INSERT, UPDATE, DELETE ON `HerediVar_ahdoebm1`.`sv_variant_hgvs` TO `HerediVar_user`@`%`
GRANT SELECT ON `HerediVar_ahdoebm1`.`variant_cancerhotspots_annotation` TO `HerediVar_user`@`%`
GRANT INSERT ON `HerediVar_ahdoebm1`.`assay` TO `HerediVar_user`@`%`
GRANT SELECT ON `HerediVar_ahdoebm1`.`automatic_classification_criteria_applied` TO `HerediVar_user`@`%`
GRANT INSERT, UPDATE, DELETE ON `HerediVar_ahdoebm1`.`user_classification_selected_literature` TO `HerediVar_user`@`%`
GRANT INSERT, UPDATE ON `HerediVar_ahdoebm1`.`user_classification` TO `HerediVar_user`@`%`
GRANT SELECT ON `HerediVar_ahdoebm1`.`mutually_inclusive_criteria` TO `HerediVar_user`@`%`
GRANT SELECT ON `HerediVar_ahdoebm1`.`assay_metadata_type` TO `HerediVar_user`@`%`
GRANT INSERT, UPDATE, DELETE ON `HerediVar_ahdoebm1`.`user_variant_lists` TO `HerediVar_user`@`%`
GRANT SELECT ON `HerediVar_ahdoebm1`.`gene_alias` TO `HerediVar_user`@`%`
GRANT SELECT ON `HerediVar_ahdoebm1`.`assay_type` TO `HerediVar_user`@`%`
GRANT INSERT, UPDATE, DELETE ON `HerediVar_ahdoebm1`.`user_classification_criteria_applied` TO `HerediVar_user`@`%`
GRANT SELECT ON `HerediVar_ahdoebm1`.`automatic_classification` TO `HerediVar_user`@`%`
GRANT SELECT, INSERT, UPDATE ON `HerediVar_ahdoebm1`.`list_variant_import_queue` TO `HerediVar_user`@`%`
GRANT INSERT, DELETE ON `HerediVar_ahdoebm1`.`list_variants` TO `HerediVar_user`@`%`
GRANT INSERT, UPDATE ON `HerediVar_ahdoebm1`.`variant` TO `HerediVar_user`@`%`
GRANT SELECT ON `HerediVar_ahdoebm1`.`variant_transcript_annotation` TO `HerediVar_user`@`%`
GRANT SELECT ON `HerediVar_ahdoebm1`.`coldspots` TO `HerediVar_user`@`%`
GRANT SELECT, INSERT ON `HerediVar_ahdoebm1`.`assay_metadata` TO `HerediVar_user`@`%`
GRANT SELECT, INSERT, UPDATE, DELETE ON `HerediVar_ahdoebm1`.`variant_sv_hgvs` TO `HerediVar_user`@`%`
GRANT SELECT, INSERT ON `HerediVar_ahdoebm1`.`variant_sv` TO `HerediVar_user`@`%`
GRANT SELECT, INSERT, UPDATE ON `HerediVar_ahdoebm1`.`user` TO `HerediVar_user`@`%`
GRANT SELECT, INSERT ON `HerediVar_ahdoebm1`.`sv_variant` TO `HerediVar_user`@`%`
GRANT INSERT, UPDATE ON `HerediVar_ahdoebm1`.`heredivar_clinvar_submissions` TO `HerediVar_user`@`%`
GRANT INSERT, UPDATE ON `HerediVar_ahdoebm1`.`annotation_queue` TO `HerediVar_user`@`%`
GRANT SELECT ON `HerediVar_ahdoebm1`.* TO `HerediVar_superuser`@`%`
GRANT SELECT ON `HerediVar_ahdoebm1`.`coldspots` TO `HerediVar_superuser`@`%`
GRANT SELECT, INSERT, UPDATE ON `HerediVar_ahdoebm1`.`annotation_queue` TO `HerediVar_superuser`@`%`
GRANT SELECT, INSERT, UPDATE, DELETE ON `HerediVar_ahdoebm1`.`classification_criterium` TO `HerediVar_superuser`@`%`
GRANT INSERT ON `HerediVar_ahdoebm1`.`consensus_classification_criteria_applied` TO `HerediVar_superuser`@`%`
GRANT INSERT, UPDATE ON `HerediVar_ahdoebm1`.`variant` TO `HerediVar_superuser`@`%`
GRANT SELECT, INSERT, UPDATE ON `HerediVar_ahdoebm1`.`user` TO `HerediVar_superuser`@`%`
GRANT SELECT ON `HerediVar_ahdoebm1`.`variant_transcript_annotation` TO `HerediVar_superuser`@`%`
GRANT INSERT, UPDATE, DELETE ON `HerediVar_ahdoebm1`.`user_classification_selected_literature` TO `HerediVar_superuser`@`%`
GRANT SELECT, INSERT, DELETE ON `HerediVar_ahdoebm1`.`mutually_inclusive_criteria` TO `HerediVar_superuser`@`%`
GRANT SELECT ON `HerediVar_ahdoebm1`.`assay_type` TO `HerediVar_superuser`@`%`
GRANT INSERT, UPDATE ON `HerediVar_ahdoebm1`.`consensus_classification` TO `HerediVar_superuser`@`%`
GRANT INSERT, UPDATE, DELETE ON `HerediVar_ahdoebm1`.`variant_ids` TO `HerediVar_superuser`@`%`
GRANT SELECT, INSERT, UPDATE ON `HerediVar_ahdoebm1`.`import_variant_queue` TO `HerediVar_superuser`@`%`
GRANT INSERT, UPDATE, DELETE ON `HerediVar_ahdoebm1`.`user_variant_lists` TO `HerediVar_superuser`@`%`
GRANT SELECT ON `HerediVar_ahdoebm1`.`variant_heredicare_annotation` TO `HerediVar_superuser`@`%`
GRANT SELECT, INSERT ON `HerediVar_ahdoebm1`.`assay_metadata` TO `HerediVar_superuser`@`%`
GRANT SELECT ON `HerediVar_ahdoebm1`.`assay_metadata_type` TO `HerediVar_superuser`@`%`
GRANT SELECT ON `HerediVar_ahdoebm1`.`gene_alias` TO `HerediVar_superuser`@`%`
GRANT SELECT, INSERT, UPDATE, DELETE ON `HerediVar_ahdoebm1`.`classification_criterium_strength` TO `HerediVar_superuser`@`%`
GRANT SELECT ON `HerediVar_ahdoebm1`.`variant_cancerhotspots_annotation` TO `HerediVar_superuser`@`%`
GRANT SELECT, INSERT, UPDATE, DELETE ON `HerediVar_ahdoebm1`.`mutually_exclusive_criteria` TO `HerediVar_superuser`@`%`
GRANT INSERT, DELETE ON `HerediVar_ahdoebm1`.`list_variants` TO `HerediVar_superuser`@`%`
GRANT INSERT, UPDATE, DELETE ON `HerediVar_ahdoebm1`.`heredivar_clinvar_submissions` TO `HerediVar_superuser`@`%`
GRANT INSERT, UPDATE ON `HerediVar_ahdoebm1`.`user_classification` TO `HerediVar_superuser`@`%`
GRANT SELECT, INSERT, UPDATE, DELETE ON `HerediVar_ahdoebm1`.`classification_scheme_alias` TO `HerediVar_superuser`@`%`
GRANT SELECT, INSERT, UPDATE, DELETE ON `HerediVar_ahdoebm1`.`variant_sv_hgvs` TO `HerediVar_superuser`@`%`
GRANT SELECT, INSERT, UPDATE ON `HerediVar_ahdoebm1`.`classification_scheme` TO `HerediVar_superuser`@`%`
GRANT SELECT ON `HerediVar_ahdoebm1`.`automatic_classification_criteria_applied` TO `HerediVar_superuser`@`%`
GRANT INSERT, UPDATE, DELETE ON `HerediVar_ahdoebm1`.`user_classification_criteria_applied` TO `HerediVar_superuser`@`%`
GRANT INSERT ON `HerediVar_ahdoebm1`.`assay` TO `HerediVar_superuser`@`%`
GRANT SELECT, INSERT, UPDATE ON `HerediVar_ahdoebm1`.`list_variant_import_queue` TO `HerediVar_superuser`@`%`
GRANT INSERT, UPDATE, DELETE ON `HerediVar_ahdoebm1`.`consensus_classification_selected_literature` TO `HerediVar_superuser`@`%`
GRANT SELECT, INSERT ON `HerediVar_ahdoebm1`.`variant_sv` TO `HerediVar_superuser`@`%`
GRANT SELECT, INSERT, UPDATE, DELETE ON `HerediVar_ahdoebm1`.`sv_variant_hgvs` TO `HerediVar_superuser`@`%`
GRANT SELECT, UPDATE ON `HerediVar_ahdoebm1`.`automatic_classification` TO `HerediVar_superuser`@`%`
GRANT SELECT, INSERT ON `HerediVar_ahdoebm1`.`sv_variant` TO `HerediVar_superuser`@`%`
GRANT INSERT, UPDATE ON `HerediVar_ahdoebm1`.`import_queue` TO `HerediVar_superuser`@`%`
GRANT SELECT, INSERT, DELETE ON `HerediVar_ahdoebm1`.`variant` TO `HerediVar_annotation`@`%`
GRANT SELECT, INSERT, UPDATE, DELETE ON `HerediVar_ahdoebm1`.`automatic_classification` TO `HerediVar_annotation`@`%`
GRANT SELECT ON `HerediVar_ahdoebm1`.`assay_metadata_type` TO `HerediVar_annotation`@`%`
GRANT SELECT, INSERT, UPDATE, DELETE ON `HerediVar_ahdoebm1`.`variant_cancerhotspots_annotation` TO `HerediVar_annotation`@`%`
GRANT SELECT, UPDATE ON `HerediVar_ahdoebm1`.`annotation_queue` TO `HerediVar_annotation`@`%`
GRANT SELECT, INSERT, UPDATE, DELETE ON `HerediVar_ahdoebm1`.`variant_ids` TO `HerediVar_annotation`@`%`
GRANT SELECT ON `HerediVar_ahdoebm1`.`gene_alias` TO `HerediVar_annotation`@`%`
GRANT SELECT ON `HerediVar_ahdoebm1`.`task_force_protein_domains` TO `HerediVar_annotation`@`%`
GRANT SELECT ON `HerediVar_ahdoebm1`.`gene` TO `HerediVar_annotation`@`%`
GRANT SELECT, INSERT ON `HerediVar_ahdoebm1`.`assay_metadata` TO `HerediVar_annotation`@`%`
GRANT SELECT ON `HerediVar_ahdoebm1`.`coldspots` TO `HerediVar_annotation`@`%`
GRANT SELECT ON `HerediVar_ahdoebm1`.`classification_scheme_alias` TO `HerediVar_annotation`@`%`
GRANT SELECT, INSERT, UPDATE ON `HerediVar_ahdoebm1`.`variant_annotation` TO `HerediVar_annotation`@`%`
GRANT SELECT ON `HerediVar_ahdoebm1`.`pfam_legacy` TO `HerediVar_annotation`@`%`
GRANT SELECT ON `HerediVar_ahdoebm1`.`user_classification` TO `HerediVar_annotation`@`%`
GRANT SELECT, INSERT, DELETE ON `HerediVar_ahdoebm1`.`variant_consequence` TO `HerediVar_annotation`@`%`
GRANT SELECT ON `HerediVar_ahdoebm1`.`transcript` TO `HerediVar_annotation`@`%`
GRANT SELECT ON `HerediVar_ahdoebm1`.`consensus_classification` TO `HerediVar_annotation`@`%`
GRANT SELECT ON `HerediVar_ahdoebm1`.`assay_type` TO `HerediVar_annotation`@`%`
GRANT SELECT, INSERT ON `HerediVar_ahdoebm1`.`variant_literature` TO `HerediVar_annotation`@`%`
GRANT SELECT, INSERT, DELETE ON `HerediVar_ahdoebm1`.`assay` TO `HerediVar_annotation`@`%`
GRANT SELECT, INSERT, UPDATE, DELETE ON `HerediVar_ahdoebm1`.`variant_heredicare_annotation` TO `HerediVar_annotation`@`%`
GRANT SELECT, INSERT, UPDATE, DELETE ON `HerediVar_ahdoebm1`.`automatic_classification_criteria_applied` TO `HerediVar_annotation`@`%`
GRANT SELECT ON `HerediVar_ahdoebm1`.`pfam_id_mapping` TO `HerediVar_annotation`@`%`
GRANT INSERT, DELETE ON `HerediVar_ahdoebm1`.`clinvar_submission` TO `HerediVar_annotation`@`%`
GRANT SELECT, INSERT, UPDATE, DELETE ON `HerediVar_ahdoebm1`.`heredicare_center_classification` TO `HerediVar_annotation`@`%`
GRANT SELECT ON `HerediVar_ahdoebm1`.`classification_scheme` TO `HerediVar_annotation`@`%`
GRANT SELECT, INSERT, UPDATE, DELETE ON `HerediVar_ahdoebm1`.`variant_transcript_annotation` TO `HerediVar_annotation`@`%`
GRANT SELECT, INSERT, DELETE ON `HerediVar_ahdoebm1`.`clinvar_variant_annotation` TO `HerediVar_annotation`@`%`
GRANT SELECT ON `HerediVar_ahdoebm1`.`sv_variant_hgvs` TO `HerediVar_annotation`@`%`
GRANT SELECT ON `HerediVar_ahdoebm1`.`annotation_type` TO `HerediVar_annotation`@`%`
